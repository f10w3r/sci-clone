#-*- coding: UTF-8 -*-
__name__ = "sci-clone"
__version__ = "0.3.3.3"
__url__ = "https://github.com/f10w3r/sci-clone"