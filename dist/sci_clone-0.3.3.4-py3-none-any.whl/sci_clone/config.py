#-*- coding: UTF-8 -*-
__name__ = "sci-clone"
__version__ = "0.3.3.4"
__url__ = "https://github.com/f10w3r/sci-clone"
__banner__ = """
                                                                 
         _____ __________     ________    ____  _   ________     
        / ___// ____/  _/    / ____/ /   / __ \/ | / / ____/     
        \__ \/ /    / /_____/ /   / /   / / / /  |/ / __/        
       ___/ / /____/ /_____/ /___/ /___/ /_/ / /|  / /___        
      /____/\____/___/     \____/_____/\____/_/ |_/_____/        
                                                                 
    A simple script for downloading articles from Sci-Hub.       
                                                                 
"""
__description__ = "A simple script for downloading articles from Sci-Hub."
__author__ = "f10w3r"
__author_email__ = "lifuminster@gmail.com"
__scihub__ = "sci-hub.tf"